<?php

use app\assets\KioskAsset;

/** @var yii\web\View $this */
/** @var array $roles */


$this->title = 'Queues';
$this->params['breadcrumbs'][] = $this->title;

KioskAsset::register($this);
?>
<div class="queues-kiosk">
    <div class="flex flex-col justify-center items-center gap-y-3" id="role-list">
    </div>
</div>
<script type="text/javascript">
    window.tokenRoles = <?= json_encode($roles) ?>;
</script>