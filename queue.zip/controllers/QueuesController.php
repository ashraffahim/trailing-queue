<?php

namespace app\controllers;

use app\components\Util;
use app\components\QueueManager;
use app\models\databaseObjects\Queue;
use app\controllers\_MainController;
use app\models\databaseObjects\Role;
use app\models\databaseObjects\UserTokenCount;
use app\models\exceptions\common\CannotSaveException;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * QueuesController implements the CRUD actions for Queue model.
 */
class QueuesController extends _MainController
{
    public function actionKiosk()
    {
        $roles = Role::find()->where(['is_open' => true, 'is_kiosk_visible' => true])->all();

        $roleArray = [];

        foreach ($roles as $role) {
            $roleArray[] = ['id' => $role->id, 'name' => $role->name];
        }

        $this->layout = 'blank';

        return $this->render('kiosk', [
            'roles' => $roleArray
        ]);
    }

    public function actionGenerate($id)
    {
        $this->response->format = Response::FORMAT_JSON;

        if (!Util::isFetchRequest()) throw new NotFoundHttpException();

        /** @var Role $role */
        $role = Role::find()->where(['id' => $id, 'is_open' => true, 'is_kiosk_visible' => true])->one();

        if (is_null($role)) throw new NotFoundHttpException('Unknown service');

        /** @var \app\models\databaseObjects\User[] $users */
        $users = $role->getUsers()->andWhere(['is_open' => true])->all();

        if (empty($users)) throw new NotFoundHttpException('All counters closed');

        $userIds = array_map(function ($user) {
            return $user->id;
        }, $users);

        /** @var UserTokenCount $userTokenCount */
        $userTokenCount = UserTokenCount::find()
            ->where(['user_id' => $userIds, 'date' => date('Y-m-d')])
            ->select(['*', 'MIN(`count` - `served`) AS `in_queue`'])
            ->orderBy(['in_queue' => SORT_ASC])
            ->limit(1)
            ->one();

        if (is_null($userTokenCount->id)) throw new NotFoundHttpException('All counters closed');

        $responseData = [];

        $transaction = \Yii::$app->db->beginTransaction();

        try {

            $assignedUser = $users[array_search($userTokenCount->user_id, $userIds)];

            $userTokenCount->count += 1;

            if (!$userTokenCount->save()) throw new CannotSaveException($userTokenCount, 'Operation failed');

            $queue = new Queue();
            $queue->token = QueueManager::createToken($role->token_prefix, $userTokenCount->count);
            $queue->user_id = $assignedUser->id;
            $queue->date = date('Y-m-d');
            $queue->time = date('h:i:s');
            $queue->status = QueueManager::STATUS_CREATED;

            if (!$queue->save()) throw new CannotSaveException($queue, 'Operation failed');

            $responseData['token'] = $queue->token;
            $responseData['floor'] = $assignedUser->floor;
            $responseData['room'] = $assignedUser->room;
            $responseData['date'] = $queue->date;
            $responseData['time'] = $queue->time;

            $transaction->commit();
        } catch (\Exception $e) {
            $transaction->rollBack();

            throw $e;
        }

        return $responseData;
    }

    public function actionCall()
    {
        $forwardRoles = Role::find()
            ->where([
                'and',
                ['!=', 'id', \Yii::$app->user->identity->role_id],
                ['is_open' => true],
                ['is_kiosk_visible' => false]
            ])
            ->all();

        $rolesArray = [];

        foreach ($forwardRoles as $role) {
            $rolesArray[] = ['id' => $role->id, 'name' => $role->name];
        }

        $this->layout = 'blank';
        return $this->render('call', [
            'openCloseText' => \Yii::$app->user->identity->is_open ? 'Close' : 'Open',
            'forwardRoles' => $rolesArray
        ]);
    }

    public function actionCallNext()
    {
        if (!Util::isFetchRequest()) throw new NotFoundHttpException();

        $user = \Yii::$app->user->identity;

        /** @var Queue $previousQueue */
        $previousQueue = Queue::find()
            ->where([
                'user_id' => $user->id,
                'date' => date('Y-m-d'),
                'status' => [
                    QueueManager::STATUS_CALLED,
                    QueueManager::STATUS_RECALLED,
                    QueueManager::STATUS_IN_PROGRESS
                ]
            ])->one();
        
        if (!is_null($previousQueue)) {
            $previousQueue->status = QueueManager::STATUS_ENDED;

            if (!$previousQueue->save()) throw new CannotSaveException($previousQueue, 'Failed');
        }

        /** @var Queue $queue */
        $queue = Queue::find()
            ->where([
                'user_id' => $user->id,
                'date' => date('Y-m-d'),
                'status' => QueueManager::STATUS_CREATED
            ])
            ->limit(1)
            ->one();

        if (is_null($queue)) {
            \Yii::$app->response->statusCode = 204;
            return $this->asJson([]);
        }

        /** @var UserTokenCount $userTokenCount */
        $userTokenCount = UserTokenCount::find()
        ->where(['user_id' => $user->id, 'date' => date('Y-m-d')])
        ->one();

        if (is_null($userTokenCount)) throw new ForbiddenHttpException('Counter closed');

        $transaction = \Yii::$app->db->beginTransaction();

        try {
            $queue->status = QueueManager::STATUS_CALLED;
            $queue->call_time = date('h:i:s');
    
            if (!$queue->save()) throw new CannotSaveException($queue, 'Failed');

            $userTokenCount->served += 1;
            $userTokenCount->last_id = $queue->id;

            if (!$userTokenCount->save()) throw new CannotSaveException($userTokenCount, 'Failed');

            $transaction->commit();
        } catch (\Exception $e) {
            $transaction->rollBack();

            throw $e;
        }

        return $this->asJson([
            'token' => $queue->token,
            'time' => $queue->time,
        ]);
    }

    public function actionRecall() {
        if (!Util::isFetchRequest()) throw new NotFoundHttpException();

        $user = \Yii::$app->user->identity;

        /** @var Queue $queue */
        $queue = Queue::find()
            ->where([
                'user_id' => $user->id,
                'date' => date('Y-m-d'),
                'status' => [QueueManager::STATUS_CALLED, QueueManager::STATUS_RECALLED]
            ])->one();

        if (is_null($queue)) {
            \Yii::$app->response->statusCode = 204;
            return $this->asJson([]);
        }

        $queue->recall_count += 1;
        $queue->recall_time = date('h:i:s');

        if (!$queue->save()) throw new CannotSaveException($queue, 'Failed');
    }

    public function actionForward($rid, $token) {}

    public function actionCallToken($token) {}

    public function actionOpenClose() {
        $this->response->format = Response::FORMAT_RAW;
        
        if (!Util::isFetchRequest()) throw new NotFoundHttpException();

        $user = \Yii::$app->user->identity;

        $userTokenCount = UserTokenCount::findOne(['user_id' => $user->id, 'date' => date('Y-m-d')]);

        $transaction = \Yii::$app->db->beginTransaction();

        try {
            $user->is_open = !$user->is_open;
    
            if (!$user->save()) throw new CannotSaveException($user, 'Failed');

            if (is_null($userTokenCount)) {
                $userTokenCount = new UserTokenCount();
                $userTokenCount->user_id = $user->id;
                $userTokenCount->count = 0;
                $userTokenCount->served = 0;
                $userTokenCount->date = date('Y-m-d');

                if (!$userTokenCount->save()) throw new CannotSaveException($userTokenCount, 'failed');
            }

            $transaction->commit();
        } catch (\Exception $e) {
            $transaction->rollBack();
        }

        return $user->is_open ? 'Close' : 'Open';
    }
}
