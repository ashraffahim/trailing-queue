<?php

namespace app\models\exceptions;

interface NotHumanExceptionInterface {}

?>