<?php

namespace app\models\exceptions\common;

use app\models\exceptions\NotHumanException;

class CannotGenerateUuidException extends NotHumanException {}

?>